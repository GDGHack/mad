import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView tv = new TextView(this);
        tv.setTextSize(24);

        String name = getIntent().getStringExtra("USER_NAME");
        tv.setText("Welcome, " + name);

        setContentView(tv);
    }
}
