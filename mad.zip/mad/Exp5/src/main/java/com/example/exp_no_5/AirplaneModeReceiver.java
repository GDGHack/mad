package com.example.exp_no_5;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class AirplaneModeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        boolean isAirplaneModeOn =
                intent.getBooleanExtra("state", false);

        if (isAirplaneModeOn) {

            Toast.makeText(context,
                    "Airplane Mode is ON",
                    Toast.LENGTH_LONG).show();

        } else {

            Toast.makeText(context,
                    "Airplane Mode is OFF",
                    Toast.LENGTH_LONG).show();
        }
    }
}