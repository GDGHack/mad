package com.example.exp_no_5;


import android.content.IntentFilter;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    AirplaneModeReceiver receiver =
            new AirplaneModeReceiver();

    @Override
    protected void onStart() {
        super.onStart();

        IntentFilter filter = new IntentFilter(
                "android.intent.action.AIRPLANE_MODE");

        registerReceiver(receiver, filter);
    }

    @Override
    protected void onStop() {
        super.onStop();

        unregisterReceiver(receiver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}