package com.example.exp_no_6;


import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    Button btnToast, btnAlert, btnPopup;
    EditText editText;

    String[] courses = {"Java", "Android", "Python"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        btnToast = findViewById(R.id.btnToast);
        btnAlert = findViewById(R.id.btnAlert);
        btnPopup = findViewById(R.id.btnPopup);
        editText = findViewById(R.id.editText);

        // Spinner

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_item,
                        courses);

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);

        // Toast

        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this,
                        "Toast Message Displayed",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Alert Dialog

        btnAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder =
                        new AlertDialog.Builder(MainActivity.this);

                builder.setTitle("Alert");
                builder.setMessage("Do you want to continue?");

                builder.setPositiveButton("Yes", null);
                builder.setNegativeButton("No", null);

                builder.show();
            }
        });

        // Popup Menu

        btnPopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popupMenu =
                        new PopupMenu(MainActivity.this, btnPopup);

                popupMenu.getMenuInflater().inflate(
                        R.menu.popup_menu,
                        popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(
                        new PopupMenu.OnMenuItemClickListener() {

                            @Override
                            public boolean onMenuItemClick(MenuItem item) {

                                Toast.makeText(MainActivity.this,
                                        item.getTitle(),
                                        Toast.LENGTH_SHORT).show();

                                return true;
                            }
                        });

                popupMenu.show();
            }
        });

        // Touch Event

        editText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v,
                                   MotionEvent event) {

                Toast.makeText(MainActivity.this,
                        "Touch Detected",
                        Toast.LENGTH_SHORT).show();

                return false;
            }
        });
    }

    // Options Menu

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        menu.add("Home");
        menu.add("About");

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Toast.makeText(this,
                item.getTitle(),
                Toast.LENGTH_SHORT).show();

        return true;
    }
}