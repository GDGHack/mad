import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button btnSetAlarm = new Button(this);
        btnSetAlarm.setText("Set Alarm in 10 Seconds");
        setContentView(btnSetAlarm);

        btnSetAlarm.setOnClickListener(v -> {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, AlarmReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

            long triggerTime = System.currentTimeMillis() + (10 * 1000);
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);

            Toast.makeText(this, "Alarm set!", Toast.LENGTH_SHORT).show();
        });
    }
}
