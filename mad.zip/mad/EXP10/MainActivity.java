import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        EditText etName = new EditText(this);
        etName.setHint("Enter Name");
        Button btnAdd = new Button(this);
        btnAdd.setText("Add Data");

        layout.addView(etName);
        layout.addView(btnAdd);
        setContentView(layout);

        myDb = new DatabaseHelper(this);

        btnAdd.setOnClickListener(v -> {
            boolean isInserted = myDb.insertData(etName.getText().toString());
            if (isInserted) {
                Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(MainActivity.this, "Data NOT Inserted", Toast.LENGTH_LONG).show();
            }
        });
    }
}
