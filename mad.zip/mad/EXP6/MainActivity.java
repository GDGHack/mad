import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    String[] courses = {"C", "C++", "Java", "Android"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.mySpinner);
        Button btnAlert = findViewById(R.id.btnAlert);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, courses);
        spinner.setAdapter(adapter);

        btnAlert.setOnClickListener(v -> {
            new AlertDialog.Builder(MainActivity.this)
                .setTitle("Confirmation")
                .setMessage("Do you want to continue?")
                .setPositiveButton("Yes", (dialog, which) -> Toast.makeText(MainActivity.this, "Clicked Yes!", Toast.LENGTH_SHORT).show())
                .setNegativeButton("No", null)
                .show();
        });
    }
}
