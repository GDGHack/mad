package com.example.exp_no_7;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class MainActivity extends AppCompatActivity {

    Button btnNotify;

    String CHANNEL_ID = "MyChannel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnNotify = findViewById(R.id.btnNotify);

        btnNotify.setOnClickListener(v -> {

            NotificationManager manager =
                    (NotificationManager)
                            getSystemService(NOTIFICATION_SERVICE);

            // Notification Channel for Android 8+

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                NotificationChannel channel =
                        new NotificationChannel(
                                CHANNEL_ID,
                                "My Notification",
                                NotificationManager.IMPORTANCE_HIGH);

                manager.createNotificationChannel(channel);
            }

            // Intent Action

            Intent intent =
                    new Intent(MainActivity.this,
                            SecondActivity.class);

            PendingIntent pendingIntent =
                    PendingIntent.getActivity(
                            MainActivity.this,
                            0,
                            intent,
                            PendingIntent.FLAG_IMMUTABLE);

            // Notification Builder

            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(
                            MainActivity.this,
                            CHANNEL_ID)

                            .setSmallIcon(android.R.drawable.ic_dialog_info)
                            .setContentTitle("Android Notification")
                            .setContentText("Click to open next activity")
                            .setPriority(
                                    NotificationCompat.PRIORITY_HIGH)
                            .setAutoCancel(true)
                            .setContentIntent(pendingIntent);

            manager.notify(1, builder.build());
        });
    }
}