package com.example.exp_no_10;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editName;
    Button btnInsert, btnView;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.editName);
        btnInsert = findViewById(R.id.btnInsert);
        btnView = findViewById(R.id.btnView);

        dbHelper = new DBHelper(this);

        // Insert Data
        btnInsert.setOnClickListener(v -> {

            String name = editName.getText().toString();
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            db.execSQL("INSERT INTO student(name) VALUES('" + name + "')");

            Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();
        });

        // View Data
        btnView.setOnClickListener(v -> {

            SQLiteDatabase db = dbHelper.getReadableDatabase();

            Cursor cursor = db.rawQuery("SELECT * FROM student", null);

            StringBuilder data = new StringBuilder();

            while (cursor.moveToNext()) {
                data.append("ID: ").append(cursor.getInt(0))
                        .append(" Name: ").append(cursor.getString(1))
                        .append("\n");
            }

            Toast.makeText(this, data.toString(), Toast.LENGTH_LONG).show();
        });
    }
}